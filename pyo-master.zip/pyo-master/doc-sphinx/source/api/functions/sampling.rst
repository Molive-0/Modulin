Resampling
=======================

.. module:: pyo

*upsamp*
---------------------------------

.. autofunction:: upsamp(path, outfile, up=4, order=128)

*downsamp*
---------------------------------

.. autofunction:: downsamp(path, outfile, down=4, order=128)

