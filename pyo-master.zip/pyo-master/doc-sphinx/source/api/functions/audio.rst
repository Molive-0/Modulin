Audio Setup
======================================

Set of functions to inspect the system's audio configuration.

.. note::

    These functions are available only if pyo is built with portaudio support.
 
.. module:: pyo

*pa_get_version*
---------------------------------

.. autofunction:: pa_get_version

*pa_get_version_text*
---------------------------------

.. autofunction:: pa_get_version_text

*pa_count_host_apis*
---------------------------------

.. autofunction:: pa_count_host_apis

*pa_list_host_apis*
---------------------------------

.. autofunction:: pa_list_host_apis

*pa_get_default_host_api*
---------------------------------

.. autofunction:: pa_get_default_host_api

*pa_get_default_devices_from_host*
-------------------------------------

.. autofunction:: pa_get_default_devices_from_host

*pa_count_devices*
---------------------------------

.. autofunction:: pa_count_devices

*pa_list_devices*
---------------------------------

.. autofunction:: pa_list_devices

*pa_get_devices_infos*
---------------------------------

.. autofunction:: pa_get_devices_infos

*pa_get_input_devices*
---------------------------------

.. autofunction:: pa_get_input_devices

*pa_get_output_devices*
---------------------------------

.. autofunction:: pa_get_output_devices

*pa_get_default_input*
---------------------------------

.. autofunction:: pa_get_default_input

*pa_get_default_output*
---------------------------------

.. autofunction:: pa_get_default_output

*pa_get_input_max_channels*
---------------------------------

.. autofunction:: pa_get_input_max_channels(x)

*pa_get_output_max_channels*
---------------------------------

.. autofunction:: pa_get_output_max_channels(x)

