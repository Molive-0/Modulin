Soundfile
=============================

.. module:: pyo

*sndinfo*
---------------------------------

.. autofunction:: sndinfo(path, print=False)

*savefile*
---------------------------------

.. autofunction:: savefile(samples, path, sr=44100, channels=1, fileformat=0, sampletype=0)

*savefileFromTable*
---------------------------------

.. autofunction:: savefileFromTable(table, path, fileformat=0, sampletype=0)

