Utilities
==================

.. module:: pyo

*example*
---------------------------------

.. autofunction:: example

*class_args*
---------------------------------

.. autofunction:: class_args

*getVersion*
---------------------------------

.. autofunction:: getVersion

*getPyoKeywords*
---------------------------------

.. autofunction:: getPyoKeywords

*withPortaudio*
---------------------------------

.. autofunction:: withPortaudio

*withPortmidi*
---------------------------------

.. autofunction:: withPortmidi

*withJack*
---------------------------------

.. autofunction:: withJack

*withCoreaudio*
---------------------------------

.. autofunction:: withCoreaudio

*withOSC*
---------------------------------

.. autofunction:: withOSC

*convertStringToSysEncoding*
---------------------------------

.. autofunction:: convertStringToSysEncoding

*convertArgsToLists*
---------------------------------

.. autofunction:: convertArgsToLists

*wrap*
---------------------------------

.. autofunction:: wrap


