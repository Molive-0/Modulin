Server Queries
======================================

.. module:: pyo

*serverCreated*
---------------------------------

.. autofunction:: serverCreated

*serverBooted*
---------------------------------

.. autofunction:: serverBooted

