Matrices
===================================

.. module:: pyo

Matrices are two-dimensions containers to keep samples (sounds, envelopes, algorithmic patterns, images, etc.)
in memory and access them quickly.

*NewMatrix*
-----------------------------------

.. autoclass:: NewMatrix
   :members:

