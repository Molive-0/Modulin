Classes by category
===============================

.. toctree::
   :maxdepth: 2

   server
   listener
   _core
   analysis
   arithmetic
   controls
   dynamics
   effects
   expression
   filters
   fourier
   pvoc
   generators
   internals
   matrixprocess
   midi
   opensndctrl
   pan
   pattern
   players
   randoms
   tableprocess
   triggers
   utils
   tables
   matrices
   map
   wxgui

