Structure of the library
==========================

This diagram shows the internal structure of the library.

.. image:: _static/structure.png
   :scale: 70
   :align: center
