Pyo is a Python module written in C to help digital signal processing script creation.

* Python 2.6 must be installed on your system before running this installer. *

http://www.python.org/download/releases/2.6.6/

To use the WxPython toolkit for widgets, you need to install wxPython 3.0 for python 2.6:

http://www.wxpython.org/download.php#stable

This installer will leave a folder called pyo_examples on the Desktop, 
it's a good starting point to explore the library!

In a Command Prompt:

cd Desktop\pyo_examples\algorithmic
python 01_music_box.py

Please, send comments and bugs to:

belangeo@gmail.com
